package com.shipping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shipping.bean.Shipping;
import com.shipping.exception.OrderException;
import com.shipping.service.OrderService;

@RestController
public class OrderController {
	@Autowired
	OrderService orderservice;
	@RequestMapping(value="/orders", method=RequestMethod.GET)
	public List <Shipping> getOrder() throws OrderException
	{
		return orderservice.getAllOrder();
	}
	@RequestMapping(value="/order", method=RequestMethod.POST)
	public Shipping addOrder(@RequestBody Shipping cust) throws OrderException{
		return orderservice.addOrder(cust);
			}
	
	@RequestMapping("/orders/{id}")
	public Shipping getOrderById(@PathVariable int id) throws OrderException{
	return orderservice.getOrderById(id);
}
	
	@RequestMapping("/getOrderByCity/city")
	public List <Shipping> findOrderrByCity(@RequestParam String city) throws OrderException{
		return orderservice.getOrderByCity(city) ;
	}
	@DeleteMapping("/orders/{id}")	
	public ResponseEntity<String> deleteCustomer(@PathVariable int id) throws OrderException {
		orderservice.deleteOrder(id);
	return new ResponseEntity<String> ("Order with id "+id+" deleted",HttpStatus.OK);
	}
	
	@PutMapping("/orders/{id}")
	public List <Shipping> updateOrder(@PathVariable int id, @RequestBody Shipping cust) throws OrderException{
		return orderservice.updateOrder(id, cust);
	}
	
}