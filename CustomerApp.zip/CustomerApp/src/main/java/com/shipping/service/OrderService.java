package com.shipping.service;

import java.util.List;

import com.shipping.bean.Shipping;
import com.shipping.exception.OrderException;

public interface OrderService {

	public Shipping addOrder(Shipping cust) throws OrderException;
	public Shipping getOrderById(int Id) throws OrderException;
	public void deleteOrder (int id) throws OrderException;
	public List<Shipping> getAllOrder() throws OrderException;
	public List<Shipping> getOrderByCity(String city) throws OrderException;
	public List<Shipping> updateOrder(int id, Shipping cust) throws OrderException;
	
	
}
